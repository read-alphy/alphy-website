import React from 'react'
import Coins from '../components/Coins'
import Trending from '../components/Trending'
import Welcome from "../components/Welcome"

function Home(props) {
    return (
        <div>
            <Welcome />
            <div name="browse">
                <Coins coins={props.coins} />
            </div>
        </div>
    )
}

export default Home